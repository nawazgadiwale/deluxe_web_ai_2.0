"use client";

import {
  Scale,
  Package,
  Tag,
  FolderTree,
  FileText,
  Layers,
} from "lucide-react";

export default function ComparisonCard({ products = [] }) {
  if (products.length === 0) return null;

  return (
    <div className="space-y-5">
      {products.map((product, index) => (
        <div
          key={index}
          className="
            overflow-hidden
            rounded-3xl
            border
            border-slate-200
            bg-white
            shadow-sm
          "
        >
          {/* ======================================
              Header
          ====================================== */}

          <div
            className="
              flex
              items-center
              justify-between
              border-b
              border-slate-100
              bg-gradient-to-r
              from-indigo-50
              to-white
              px-5
              py-4
            "
          >
            <div className="flex items-center gap-3">
              <div
                className="
                  flex
                  h-12
                  w-12
                  items-center
                  justify-center
                  rounded-2xl
                  bg-indigo-100
                "
              >
                <Scale size={22} className="text-indigo-600" />
              </div>

              <div>
                <h3 className="font-semibold text-slate-900">{product.name}</h3>

                <p className="text-xs text-slate-500">Comparison Candidate</p>
              </div>
            </div>
          </div>

          {/* ======================================
              Body
          ====================================== */}

          <div className="space-y-5 p-5">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Tag size={16} className="text-blue-600" />

                  <span className="font-medium">Category</span>
                </div>

                <p className="text-sm text-slate-600">{product.category}</p>
              </div>

              <div className="rounded-2xl border border-slate-200 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <FolderTree size={16} className="text-blue-600" />

                  <span className="font-medium">Sub Category</span>
                </div>

                <p className="text-sm text-slate-600">{product.subCategory}</p>
              </div>
            </div>

            {/* Description */}

            {product.description && (
              <div
                className="
                  rounded-2xl
                  border
                  border-blue-100
                  bg-blue-50
                  p-4
                "
              >
                <div className="mb-2 flex items-center gap-2">
                  <FileText size={16} className="text-blue-600" />

                  <span className="font-medium">Description</span>
                </div>

                <p className="text-sm leading-7 text-slate-600">
                  {product.description}
                </p>
              </div>
            )}

            {/* Applications */}

            {(product.applications ?? []).length > 0 && (
              <div>
                <div className="mb-3 font-medium">Applications</div>

                <div className="flex flex-wrap gap-2">
                  {product.applications.map((app) => (
                    <span
                      key={app}
                      className="
                        rounded-full
                        bg-blue-100
                        px-3
                        py-1
                        text-xs
                        text-blue-700
                      "
                    >
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Related Products */}

            {(product.relatedProducts ?? []).length > 0 && (
              <div>
                <div className="mb-3 flex items-center gap-2">
                  <Layers size={16} className="text-blue-600" />

                  <span className="font-medium">Related Products</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {product.relatedProducts.map((item) => (
                    <span
                      key={item}
                      className="
                        rounded-full
                        bg-slate-100
                        px-3
                        py-1
                        text-xs
                        text-slate-600
                      "
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

"use client";

import {
  Package,
  Tag,
  FolderTree,
  FileText,
  CheckCircle2,
  Layers,
} from "lucide-react";

import RelatedProducts from "./RelatedProductCard";

export default function ProductDetailsCard({
  product,
  summary,
  description,
  applications = [],
  variants = [],
  specifications = {},
  relatedProducts = [],
}) {
  if (!product) return null;

  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
      {/* ==========================================
          Header
      ========================================== */}

      <div className="border-b border-slate-100 bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-6 text-white">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20">
            <Package size={28} />
          </div>

          <div>
            <h2 className="text-2xl font-bold">
              {product.name ?? product.product}
            </h2>

            <p className="mt-1 text-sm text-blue-100">{product.category}</p>
          </div>
        </div>
      </div>

      <div className="space-y-6 p-6">
        {/* ==========================================
            Summary
        ========================================== */}

        {summary && (
          <div className="rounded-2xl border border-blue-100 bg-blue-50 p-5">
            <div className="mb-3 flex items-center gap-2 font-semibold">
              <FileText size={18} className="text-blue-600" />
              AI Summary
            </div>

            <p className="leading-7 text-slate-700">{summary}</p>
          </div>
        )}

        {/* ==========================================
            Description
        ========================================== */}

        {description && (
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold">
              <FileText size={18} className="text-blue-600" />
              Description
            </h3>

            <p className="leading-7 text-slate-600">{description}</p>
          </div>
        )}

        {/* ==========================================
            Product Information
        ========================================== */}

        <div className="grid gap-4 md:grid-cols-2">
          {product.category && (
            <div className="rounded-2xl border border-slate-200 p-4">
              <div className="mb-2 flex items-center gap-2">
                <Tag size={16} className="text-blue-600" />
                Category
              </div>

              <div className="font-medium">{product.category}</div>
            </div>
          )}

          {product.subCategory && (
            <div className="rounded-2xl border border-slate-200 p-4">
              <div className="mb-2 flex items-center gap-2">
                <FolderTree size={16} className="text-blue-600" />
                Sub Category
              </div>

              <div className="font-medium">{product.subCategory}</div>
            </div>
          )}
        </div>

        {/* ==========================================
            Applications
        ========================================== */}

        {applications.length > 0 && (
          <div>
            <h3 className="mb-4 text-lg font-semibold">Applications</h3>

            <div className="flex flex-wrap gap-2">
              {applications.map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-2 rounded-full bg-blue-50 px-4 py-2 text-sm text-blue-700"
                >
                  <CheckCircle2 size={14} />

                  {item}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==========================================
            Variants
        ========================================== */}

        {variants.length > 0 && (
          <div>
            <h3 className="mb-4 text-lg font-semibold">Available Variants</h3>

            <div className="flex flex-wrap gap-2">
              {variants.map((item) => (
                <span
                  key={item}
                  className="rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-sm"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* ==========================================
            Specifications
        ========================================== */}

        {Object.keys(specifications).length > 0 && (
          <div>
            <h3 className="mb-4 text-lg font-semibold">Specifications</h3>

            <div className="overflow-hidden rounded-2xl border border-slate-200">
              {Object.entries(specifications).map(([key, value]) => (
                <div
                  key={key}
                  className="flex items-center justify-between border-b border-slate-100 px-5 py-4 last:border-b-0"
                >
                  <span className="font-medium capitalize">{key}</span>

                  <span className="text-slate-600">{String(value)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==========================================
            Related Products
        ========================================== */}

        {relatedProducts.length > 0 && (
          <div>
            <div className="mb-4 flex items-center gap-2 text-lg font-semibold">
              <Layers size={18} className="text-blue-600" />
              Related Products
            </div>

            <RelatedProducts title="" items={relatedProducts} />
          </div>
        )}
      </div>
    </div>
  );
}

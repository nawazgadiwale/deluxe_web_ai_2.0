"use client";

import {
  Bot,
  ClipboardList,
  CheckCircle2,
  AlertCircle,
  Package,
  Calendar,
  Palette,
  Hash,
  User,
  Phone,
  Mail,
} from "lucide-react";

import ActionButton from "./ActionButton";

export default function OrderCard({
  step,
  message,
  question,
  items = [],
  customer,
  assignedTo,
  actions = [],
}) {
  /*
   * =====================================================
   * Progress
   * =====================================================
   */

  const STEP_PROGRESS = {
    ASK_PRODUCT: 10,
    ASK_QUANTITY: 20,
    ASK_ARTWORK: 30,
    ASK_DESIGN_REQUIREMENTS: 40,
    ASK_DEADLINE: 50,
    ASK_SPECIFICATION: 60,
    ASK_NOTES: 70,
    ASK_UPSELL: 80,
    ASK_ADD_MORE: 85,
    ASK_CONFIRM: 90,
    ASK_NAME: 94,
    ASK_MOBILE: 97,
    ASK_EMAIL: 99,
    COMPLETE: 100,
    ORDER_COMPLETED: 100,
  };

  const progress = STEP_PROGRESS[step] ?? 0;

  const currentItem = items.length > 0 ? items[items.length - 1] : null;

  function InfoRow({ icon, label, value }) {
    return (
      <div className="flex items-center gap-3 rounded-xl bg-white border border-slate-200 px-4 py-3">
        <div className="text-blue-600">{icon}</div>

        <div>
          <div className="text-xs uppercase tracking-wide text-slate-400">
            {label}
          </div>

          <div className="font-medium text-slate-800">{value || "-"}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-md">
      {/* =====================================================
          Header
      ===================================================== */}

      <div className="border-b border-slate-100 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 px-6 py-5 text-white">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-600">
            <Bot size={24} />
          </div>

          <div>
            <h2 className="text-lg font-semibold">Deluxe AI Assistant</h2>

            <p className="text-sm text-slate-300">
              Let's complete your printing order.
            </p>
          </div>
        </div>
      </div>

      {/* =====================================================
          Progress
      ===================================================== */}

      <div className="px-6 pt-5">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-medium text-slate-700">
            Order Progress
          </span>

          <span className="text-sm font-semibold text-blue-600">
            {progress}%
          </span>
        </div>

        <div className="h-2 overflow-hidden rounded-full bg-slate-200">
          <div
            className="h-full rounded-full bg-blue-600 transition-all duration-500"
            style={{
              width: `${progress}%`,
            }}
          />
        </div>
      </div>

      <div className="space-y-5 p-6">
        {/* =====================================================
          Current Question
      ===================================================== */}

        {(message || question) && (
          <div className="rounded-2xl bg-blue-50 border border-blue-100 p-5">
            <div className="flex items-start gap-3">
              <div className="mt-1 flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white">
                <ClipboardList size={18} />
              </div>

              <div>
                {message && (
                  <p className="text-slate-700 leading-7">{message}</p>
                )}

                {question && (
                  <p className="mt-2 font-medium text-slate-900">{question}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* =====================================================
          Current Order
      ===================================================== */}

        {items.length > 0 && (
          <div className="rounded-2xl border border-slate-200">
            <div className="border-b border-slate-100 px-5 py-4">
              <h3 className="font-semibold text-slate-900">Current Order</h3>
            </div>

            <div className="space-y-4 p-5">
              {items.map((item, index) => (
                <div
                  key={index}
                  className="rounded-2xl bg-slate-50 border border-slate-100 p-4"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100">
                        <Package size={20} className="text-blue-600" />
                      </div>

                      <div>
                        <div className="font-semibold text-slate-900">
                          {item.product}
                        </div>

                        <div className="text-xs text-slate-500">
                          {item.mainCategory}
                        </div>
                      </div>
                    </div>

                    <div className="rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                      Active
                    </div>
                  </div>

                  <div className="mt-5 grid gap-3 md:grid-cols-2">
                    <InfoRow
                      icon={<Hash size={15} />}
                      label="Quantity"
                      value={item.quantity}
                    />

                    <InfoRow
                      icon={<Calendar size={15} />}
                      label="Deadline"
                      value={item.deadline}
                    />

                    <InfoRow
                      icon={<Palette size={15} />}
                      label="Artwork"
                      value={item.artworkStatus}
                    />

                    <InfoRow
                      icon={<ClipboardList size={15} />}
                      label="Design"
                      value={item.designRequirements}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* =====================================================
          Customer Information
      ===================================================== */}

      {customer && (
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
          <div className="mb-4 flex items-center gap-2">
            <User size={18} className="text-blue-600" />

            <h3 className="font-semibold">Customer Information</h3>
          </div>

          <div className="grid gap-3">
            {customer.name && (
              <InfoRow
                icon={<User size={15} />}
                label="Name"
                value={customer.name}
              />
            )}

            {customer.mobile && (
              <InfoRow
                icon={<Phone size={15} />}
                label="Mobile"
                value={customer.mobile}
              />
            )}

            {customer.email && (
              <InfoRow
                icon={<Mail size={15} />}
                label="Email"
                value={customer.email}
              />
            )}
          </div>
        </div>
      )}

      {/* =====================================================
          Sales Representative
      ===================================================== */}

      {assignedTo && (
        <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
          <div className="font-semibold text-slate-900">
            Assigned Sales Specialist
          </div>

          <div className="mt-3">
            <div className="font-medium">{assignedTo.name}</div>

            <div className="text-sm text-slate-500">{assignedTo.role}</div>
          </div>
        </div>
      )}

      {/* =====================================================
          Actions
      ===================================================== */}

      {actions.length > 0 && (
        <div className="space-y-3">
          <div className="text-sm font-semibold text-slate-500 uppercase tracking-wide">
            Available Actions
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {actions.map((action) => (
              <ActionButton key={action.id} action={action} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

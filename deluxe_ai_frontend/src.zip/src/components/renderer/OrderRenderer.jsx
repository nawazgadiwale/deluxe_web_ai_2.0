"use client";

import OrderCard from "../cards/OrderCard";

export default function OrderRenderer({
  data = {},
  message = "",
  actions = [],
}) {
  if (!data) {
    return null;
  }

  return (
    <OrderCard
      /* =========================================
         Backend Workflow
      ========================================= */

      step={data.step}
      question={data.question}
      message={message || data.message || data.summary}
      /* =========================================
         Order Data
      ========================================= */

      items={data.items ?? []}
      customer={data.customer ?? null}
      assignedTo={data.assignedTo ?? null}
      /* =========================================
         Validation
      ========================================= */

      errors={data.errors ?? []}
      missingFields={data.missingFields ?? []}
      /* =========================================
         Backend Actions
      ========================================= */

      actions={actions.length ? actions : (data.actions ?? [])}
      /* =========================================
         Extra Backend Data
      ========================================= */

      recommendations={data.recommendations ?? []}
      followUpQuestion={data.followUpQuestion}
      metadata={data.metadata ?? {}}
    />
  );
}

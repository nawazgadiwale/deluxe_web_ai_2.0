"use client";

import { Scale } from "lucide-react";

import SummaryCard from "../cards/SummaryCard";
import ComparisonCard from "../cards/ComparisonCard";
import ActionButton from "../cards/ActionButton";

export default function ComparisonRenderer({ data = {}, actions = [] }) {
  const { summary, products = [] } = data;

  return (
    <div className="space-y-5">
      {/* ======================================
          Summary
      ====================================== */}

      {summary && (
        <SummaryCard
          title="AI Product Comparison"
          summary={summary}
          icon={Scale}
        />
      )}

      {/* ======================================
          Products
      ====================================== */}

      {products.length > 0 && <ComparisonCard products={products} />}

      {/* ======================================
          Actions
      ====================================== */}

      {actions.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {actions.map((action) => (
            <ActionButton key={action.id} action={action} />
          ))}
        </div>
      )}
    </div>
  );
}

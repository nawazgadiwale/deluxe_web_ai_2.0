"use client";

import ProductDetailsCard from "../cards/ProductDetailsCard";
import ActionButton from "../cards/ActionButton";

export default function ProductDetailsRenderer({ data = {}, actions = [] }) {
  const product = data.product;

  if (!product) return null;

  const responseActions = actions.length > 0 ? actions : (data.actions ?? []);

  return (
    <div className="space-y-5">
      <ProductDetailsCard product={product} summary={data.summary} />

      {responseActions.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {responseActions.map((action) => (
            <ActionButton key={action.id} action={action} />
          ))}
        </div>
      )}
    </div>
  );
}
